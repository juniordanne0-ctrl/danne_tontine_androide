# DANNE TONTINE — préparer une application Android (APK)

## Ce qui est préparé

Le projet Web original est conservé. La coque Android utilise Capacitor et ouvre le site DANNE TONTINE publié en HTTPS. Les formulaires, l'authentification et les données restent servis par l'application existante et sa base MySQL; aucune seconde application métier n'est créée.

Le projet contient également un manifeste Web et des icônes noir et or pour l'installation depuis un navigateur compatible. Ce manifeste ne fournit pas de mode hors ligne; la connexion à Internet et au serveur restent nécessaires.

## Prérequis avant la compilation Android

1. **Publier le serveur Web** dans le projet Manus et vérifier que la nouvelle version est disponible. Choisir un déploiement avec serveur, car l'interface appelle Express/tRPC et la base de données gérée. Utiliser le domaine HTTPS stable fourni par la publication.
2. **Ne pas utiliser l'URL Preview** comme adresse de production : un aperçu n'est pas l'hébergement public durable requis pour l'application.
3. Installer Android Studio et le SDK Android sur un ordinateur de développement, ou dans un environnement CI configuré pour Android. Le poste doit disposer d'un JDK compatible avec la version du Gradle/Android Gradle Plugin du projet.
4. Depuis la racine du projet, avec Node.js et pnpm installés, définir l'URL publiée et synchroniser les fichiers Android :

   ```bash
   pnpm install --frozen-lockfile
   DANNE_APP_URL="https://VOTRE-DOMAINE-PUBLIE" pnpm android:sync
   pnpm exec cap open android
   ```

   Remplacer `https://VOTRE-DOMAINE-PUBLIE` par le vrai domaine HTTPS. Ne pas conserver les chevrons.

5. Dans Android Studio, attendre la synchronisation Gradle, puis choisir **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Le fichier de débogage est normalement créé dans `android/app/build/outputs/apk/debug/app-debug.apk`.
6. Pour distribuer l'application ou la publier sur Google Play, créer une version **signée** depuis Android Studio et protéger la clé de signature. Aucune clé de signature n'est incluse dans le dépôt ni dans l'archive source.

## Compilation locale avec la ligne de commande

Après avoir installé Android Studio/SDK et accepté les licences Android, le projet peut aussi être compilé depuis un terminal configuré avec `ANDROID_HOME`/`ANDROID_SDK_ROOT` :

```bash
DANNE_APP_URL="https://VOTRE-DOMAINE-PUBLIE" pnpm android:sync
cd android
./gradlew assembleDebug
```

Le résultat attendu est `android/app/build/outputs/apk/debug/app-debug.apk`.

## Limite vérifiée de cette session

La session Manus qui contient le projet a Java 21, mais pas Android SDK, `sdkmanager`, `adb` ni Gradle global. Elle peut préparer et archiver le code, mais **ne peut pas compiler/vérifier un APK Android dans cet environnement en l'état**. Aucun APK n'est fourni ici. Android Studio (ou un CI Android configuré) est nécessaire pour générer et signer le fichier installable.

## Conseils d'installation sur un téléphone

Pour un APK de débogage, transférer le fichier `.apk` sur le téléphone Android, l'ouvrir et autoriser temporairement l'installation pour l'application de fichiers utilisée. Installer uniquement un APK que vous avez compilé ou obtenu d'une source de confiance. L'application empaquetée requiert une connexion au domaine publié.

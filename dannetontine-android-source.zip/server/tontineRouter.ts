import { TRPCError } from "@trpc/server";
import { randomBytes } from "node:crypto";
import { z } from "zod";
import { execute, query, withTransaction } from "./appDb";
import { normalizePhone } from "./localAuth";
import { protectedProcedure, router } from "./_core/trpc";

const groupInput = z.object({ tontineId: z.number().int().positive() });
const methods = z.enum(["cash", "mtn_momo", "orange_money", "bank_transfer", "other"]);
const frequencies = z.enum(["daily", "weekly", "monthly", "custom"]);
const statuses = z.enum(["active", "suspended", "blocked", "archived"]);
type Role = "admin" | "treasurer" | "member";

async function access(userId: number, tontineId: number, allowed?: Role[]) {
  const rows = await query("SELECT m.role,t.isDemo FROM tontine_memberships m JOIN tontines t ON t.id=m.tontineId WHERE m.userId=? AND m.tontineId=? LIMIT 1", [userId, tontineId]);
  if (!rows.length) throw new TRPCError({ code: "FORBIDDEN", message: "Vous n’avez pas accès à cette tontine." });
  const role = rows[0].role as Role;
  if (allowed && !allowed.includes(role)) throw new TRPCError({ code: "FORBIDDEN", message: "Votre rôle ne permet pas cette action." });
  return { role, isDemo: Number(rows[0].isDemo) === 1 };
}

async function assertMemberInGroup(memberId: number, tontineId: number) {
  const rows = await query("SELECT id FROM members WHERE id=? AND tontineId=? LIMIT 1", [memberId, tontineId]);
  if (!rows.length) throw new TRPCError({ code: "NOT_FOUND", message: "Membre introuvable dans cette tontine." });
}

async function linkedMemberId(userId: number, tontineId: number) {
  const rows = await query("SELECT id FROM members WHERE tontineId=? AND linkedUserId=? LIMIT 1", [tontineId, userId]);
  if (!rows.length) throw new TRPCError({ code: "FORBIDDEN", message: "Aucun profil membre n’est rattaché à ce compte." });
  return Number(rows[0].id);
}

async function audit(tontineId: number, actorId: number, entityType: string, entityId: number | string | null, action: string, details: unknown, status: string, amount?: number, isDemo = false) {
  await execute("INSERT INTO audit_logs (tontineId,actorId,entityType,entityId,action,amount,details,status,isDemo) VALUES (?,?,?,?,?,?,?,?,?)", [tontineId, actorId, entityType, entityId == null ? null : String(entityId), action, amount ?? null, JSON.stringify(details ?? {}), status, isDemo ? 1 : 0]);
}

function money(value: number) {
  if (!Number.isSafeInteger(value) || value <= 0 || value > 1_000_000_000) throw new TRPCError({ code: "BAD_REQUEST", message: "Saisissez un montant positif valide en FCFA." });
  return value;
}

function localDate(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || Number.isNaN(Date.parse(`${value}T00:00:00`))) throw new TRPCError({ code: "BAD_REQUEST", message: "Date invalide." });
  return value;
}

const listMemberProcedure = protectedProcedure.input(groupInput.extend({ search: z.string().max(120).optional(), status: statuses.optional() })).query(async ({ input, ctx }) => {
  const {role}=await access(ctx.user.id, input.tontineId);
  const terms: unknown[] = [input.tontineId];
  let sql = "SELECT m.*, (SELECT COALESCE(SUM(c.amount),0) FROM contributions c WHERE c.memberId=m.id AND c.status='confirmed') AS amountPaid FROM members m WHERE m.tontineId=?";
  if(role==="member"){sql+=" AND m.linkedUserId=?";terms.push(ctx.user.id);}
  if (input.status) { sql += " AND m.status=?"; terms.push(input.status); }
  if (input.search) { sql += " AND (m.fullName LIKE ? OR m.phone LIKE ?)"; terms.push(`%${input.search}%`, `%${input.search}%`); }
  sql += " ORDER BY m.status='active' DESC, m.fullName";
  return query(sql, terms);
});

export const tontineRouter = router({
  dashboard: protectedProcedure.input(groupInput).query(async ({ input, ctx }) => {
    const {role}=await access(ctx.user.id, input.tontineId);
    if(role==="member"){
      const memberId=await linkedMemberId(ctx.user.id,input.tontineId);
      const [self]=await query("SELECT m.expectedAmount,m.status,COALESCE((SELECT SUM(amount) FROM contributions WHERE memberId=m.id AND status='confirmed'),0) AS collected,COALESCE((SELECT SUM(amount) FROM payouts WHERE memberId=m.id AND status='paid'),0) AS paidOut FROM members m WHERE m.id=?",[memberId]);
      const next=await query("SELECT t.id,t.position,t.plannedDate,t.plannedAmount,m.fullName FROM beneficiary_turns t JOIN members m ON m.id=t.memberId WHERE t.tontineId=? AND t.memberId=? AND t.status='planned' ORDER BY t.position LIMIT 1",[input.tontineId,memberId]);
      return{collected:Number(self?.collected??0),paidOut:Number(self?.paidOut??0),balance:Number(self?.collected??0)-Number(self?.paidOut??0),activeMembers:self?.status==="active"?1:0,overdueMembers:0,blockedMembers:self?.status==="blocked"?1:0,suspendedMembers:self?.status==="suspended"?1:0,expected:Number(self?.expectedAmount??0),nextBeneficiary:next[0]??null,chart:[],latest:[]};
    }
    const [s] = await query(`SELECT
      COALESCE((SELECT SUM(amount) FROM contributions WHERE tontineId=? AND status='confirmed'),0) AS collected,
      COALESCE((SELECT SUM(amount) FROM payouts WHERE tontineId=? AND status='paid'),0) AS paidOut,
      (SELECT COUNT(*) FROM members WHERE tontineId=? AND status='active') AS activeMembers,
      (SELECT COUNT(*) FROM members WHERE tontineId=? AND status='blocked') AS blockedMembers,
      (SELECT COUNT(*) FROM members WHERE tontineId=? AND status='suspended') AS suspendedMembers,
      (SELECT COALESCE(SUM(expectedAmount),0) FROM members WHERE tontineId=? AND status='active') AS expected`, [input.tontineId,input.tontineId,input.tontineId,input.tontineId,input.tontineId,input.tontineId]);
    const delayRows = await query("SELECT m.id,m.expectedAmount,m.frequency,m.joinedAt,COALESCE(c.paid,0) AS paid FROM members m LEFT JOIN (SELECT memberId,SUM(amount) AS paid FROM contributions WHERE tontineId=? AND status='confirmed' GROUP BY memberId) c ON c.memberId=m.id WHERE m.tontineId=? AND m.status='active'", [input.tontineId,input.tontineId]);
    const now = new Date();
    const overdue = delayRows.filter(row => {
      const joined = new Date(`${String(row.joinedAt).slice(0,10)}T00:00:00Z`);
      const days = Math.max(0, Math.floor((Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate()) - Date.UTC(joined.getUTCFullYear(),joined.getUTCMonth(),joined.getUTCDate())) / 86400000));
      const freq = String(row.frequency);
      const due = freq === "daily" ? days : freq === "weekly" ? Math.floor(days/7) : freq === "monthly" ? Math.max(0,(now.getFullYear()-joined.getFullYear())*12 + now.getMonth()-joined.getMonth()) : 0;
      return due * Number(row.expectedAmount) > Number(row.paid);
    }).length;
    const chart = await query(`SELECT DATE_FORMAT(paidAt,'%Y-%m') AS month, SUM(amount) AS total, 'cotisation' AS type FROM contributions WHERE tontineId=? AND status='confirmed' AND paidAt>=DATE_SUB(CURRENT_DATE,INTERVAL 6 MONTH) GROUP BY DATE_FORMAT(paidAt,'%Y-%m')
      UNION ALL SELECT DATE_FORMAT(paidAt,'%Y-%m') AS month, SUM(amount) AS total, 'paiement' AS type FROM payouts WHERE tontineId=? AND status='paid' AND paidAt>=DATE_SUB(CURRENT_DATE,INTERVAL 6 MONTH) GROUP BY DATE_FORMAT(paidAt,'%Y-%m') ORDER BY month`, [input.tontineId,input.tontineId]);
    const next = await query("SELECT t.id,t.position,t.plannedDate,t.plannedAmount,m.fullName FROM beneficiary_turns t JOIN members m ON m.id=t.memberId WHERE t.tontineId=? AND t.status='planned' ORDER BY t.position LIMIT 1", [input.tontineId]);
    const latest = await query("SELECT a.id,a.entityType,a.entityId,a.action,a.amount,a.status,a.createdAt,a.details,u.name AS actorName FROM audit_logs a JOIN users u ON u.id=a.actorId WHERE a.tontineId=? ORDER BY a.createdAt DESC LIMIT 7", [input.tontineId]);
    const currentCycle = Number(s.expected ?? 0);
    return { collected:Number(s.collected??0), paidOut:Number(s.paidOut??0), balance:Number(s.collected??0)-Number(s.paidOut??0), activeMembers:Number(s.activeMembers??0), overdueMembers:overdue, blockedMembers:Number(s.blockedMembers??0), suspendedMembers:Number(s.suspendedMembers??0), expected:currentCycle, nextBeneficiary:next[0]??null, chart, latest };
  }),

  members: router({
    list: listMemberProcedure,
    save: protectedProcedure.input(groupInput.extend({ id:z.number().int().positive().optional(), fullName:z.string().trim().min(2).max(160), phone:z.string().trim().min(7).max(40), email:z.string().trim().max(320).optional().or(z.literal("")), address:z.string().max(500).optional(), joinedAt:z.string(), expectedAmount:z.number().int().min(0).max(1_000_000_000), frequency:frequencies, status:statuses, notes:z.string().max(3000).optional() })).mutation(async ({ input,ctx }) => {
      const {isDemo,role}=await access(ctx.user.id,input.tontineId,["admin","treasurer"]);
      const joined=localDate(input.joinedAt); let phone:string; try{phone=normalizePhone(input.phone);}catch{throw new TRPCError({code:"BAD_REQUEST",message:"Numéro de téléphone invalide."});}
      if(input.id){await assertMemberInGroup(input.id,input.tontineId); const [old]=await query("SELECT * FROM members WHERE id=? AND tontineId=?",[input.id,input.tontineId]);
        if(role!=="admin" && input.status!==old?.status) throw new TRPCError({code:"FORBIDDEN",message:"Seul l’administrateur peut modifier le statut d’un membre."});
        await execute("UPDATE members SET fullName=?,phone=?,email=?,address=?,joinedAt=?,expectedAmount=?,frequency=?,status=?,notes=? WHERE id=? AND tontineId=?",[input.fullName,phone,input.email||null,input.address||null,joined,input.expectedAmount,input.frequency,input.status,input.notes||null,input.id,input.tontineId]);
        await audit(input.tontineId,ctx.user.id,"member",input.id,"updated",{before:old,after:input},input.status,undefined,isDemo); return {id:input.id};}
      if(role!=="admin" && input.status!=="active") throw new TRPCError({code:"FORBIDDEN",message:"Seul l’administrateur peut créer des membres avec un statut différent d’actif."});
      const publicId=`DT-${cryptoRandom().slice(0,10).toUpperCase()}`;
      const result=await execute("INSERT INTO members (publicId,tontineId,fullName,phone,email,address,joinedAt,expectedAmount,frequency,status,notes,isDemo) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",[publicId,input.tontineId,input.fullName,phone,input.email||null,input.address||null,joined,input.expectedAmount,input.frequency,input.status,input.notes||null,isDemo?1:0]);
      await audit(input.tontineId,ctx.user.id,"member",result.insertId,"created",{name:input.fullName,phone},input.status,undefined,isDemo); return {id:result.insertId,publicId};
    }),
    status: protectedProcedure.input(groupInput.extend({id:z.number().int().positive(),status:statuses,reason:z.string().trim().min(3).max(500)})).mutation(async ({input,ctx})=>{
      const {isDemo}=await access(ctx.user.id,input.tontineId,["admin"]); await assertMemberInGroup(input.id,input.tontineId);
      const [old]=await query("SELECT status,fullName FROM members WHERE id=? AND tontineId=?",[input.id,input.tontineId]);
      await execute("UPDATE members SET status=? WHERE id=? AND tontineId=?",[input.status,input.id,input.tontineId]);
      await audit(input.tontineId,ctx.user.id,"member",input.id,input.status==="blocked"?"blocked":input.status==="active"?"reactivated":"status_changed",{from:old?.status,to:input.status,reason:input.reason,at:new Date().toISOString()},input.status,undefined,isDemo);
      return {success:true};
    }),
    detail: protectedProcedure.input(groupInput.extend({id:z.number().int().positive()})).query(async({input,ctx})=>{
      const {role}=await access(ctx.user.id,input.tontineId); await assertMemberInGroup(input.id,input.tontineId);
      if(role==="member" && await linkedMemberId(ctx.user.id,input.tontineId)!==input.id)throw new TRPCError({code:"FORBIDDEN",message:"Vous ne pouvez consulter que votre propre fiche."});
      const [member]=await query("SELECT * FROM members WHERE id=? AND tontineId=?",[input.id,input.tontineId]);
      const c=await query("SELECT * FROM contributions WHERE memberId=? AND tontineId=? ORDER BY paidAt DESC",[input.id,input.tontineId]);
      const p=await query("SELECT * FROM payouts WHERE memberId=? AND tontineId=? ORDER BY createdAt DESC",[input.id,input.tontineId]);
      return {member,contributions:c,payouts:p};
    }),
  }),

  contributions: router({
    list: protectedProcedure.input(groupInput.extend({memberId:z.number().int().positive().optional(),from:z.string().optional(),to:z.string().optional(),status:z.enum(["confirmed","reversed"]).optional()})).query(async({input,ctx})=>{
      const {role}=await access(ctx.user.id,input.tontineId); let sql="SELECT c.*,m.fullName,m.phone,u.name AS actorName FROM contributions c JOIN members m ON m.id=c.memberId JOIN users u ON u.id=c.createdBy WHERE c.tontineId=?"; const args:unknown[]=[input.tontineId];
      if(role==="member"){const own=await linkedMemberId(ctx.user.id,input.tontineId);if(input.memberId&&input.memberId!==own)throw new TRPCError({code:"FORBIDDEN",message:"Vous ne pouvez consulter que vos cotisations."});sql+=" AND c.memberId=?";args.push(own);}
      if(input.memberId){sql+=" AND c.memberId=?";args.push(input.memberId);} if(input.from){sql+=" AND c.paidAt>=?";args.push(`${localDate(input.from)} 00:00:00`);}if(input.to){sql+=" AND c.paidAt<=?";args.push(`${localDate(input.to)} 23:59:59`);}if(input.status){sql+=" AND c.status=?";args.push(input.status);}sql+=" ORDER BY c.paidAt DESC LIMIT 500";return query(sql,args);
    }),
    create: protectedProcedure.input(groupInput.extend({memberId:z.number().int().positive(),amount:z.number().int().positive().max(1_000_000_000),paidAt:z.string(),paymentMethod:methods,reference:z.string().max(120).optional(),comment:z.string().max(1000).optional()})).mutation(async({input,ctx})=>{
      const {isDemo}=await access(ctx.user.id,input.tontineId,["admin","treasurer"]);await assertMemberInGroup(input.memberId,input.tontineId);const paidAt=new Date(input.paidAt);if(Number.isNaN(paidAt.getTime()))throw new TRPCError({code:"BAD_REQUEST",message:"Date de paiement invalide."});
      const dupe=await query("SELECT id FROM contributions WHERE tontineId=? AND memberId=? AND amount=? AND DATE(paidAt)=DATE(?) AND status='confirmed' LIMIT 1",[input.tontineId,input.memberId,input.amount,paidAt]);if(dupe.length)throw new TRPCError({code:"CONFLICT",message:"Une cotisation similaire existe déjà pour ce membre et cette date."});
      const r=await execute("INSERT INTO contributions (tontineId,memberId,amount,paidAt,paymentMethod,reference,comment,status,isManual,isDemo,createdBy) VALUES (?,?,?,?,?,?,?,'confirmed',1,?,?)",[input.tontineId,input.memberId,money(input.amount),paidAt,input.paymentMethod,input.reference||null,input.comment||null,isDemo?1:0,ctx.user.id]);
      await audit(input.tontineId,ctx.user.id,"contribution",r.insertId,"recorded",{memberId:input.memberId,method:input.paymentMethod,reference:input.reference||null,manual:true},"confirmed",input.amount,isDemo);return{id:r.insertId};
    }),
    correct: protectedProcedure.input(groupInput.extend({id:z.number().int().positive(),amount:z.number().int().positive().max(1_000_000_000),paidAt:z.string(),paymentMethod:methods,reference:z.string().max(120).optional(),comment:z.string().max(1000).optional(),reason:z.string().trim().min(3).max(500)})).mutation(async({input,ctx})=>{
      const {isDemo}=await access(ctx.user.id,input.tontineId,["admin"]);const [old]=await query("SELECT * FROM contributions WHERE id=? AND tontineId=? AND status='confirmed'",[input.id,input.tontineId]);if(!old)throw new TRPCError({code:"NOT_FOUND",message:"Cotisation introuvable."});const paidAt=new Date(input.paidAt);if(Number.isNaN(paidAt.getTime()))throw new TRPCError({code:"BAD_REQUEST",message:"Date invalide."});
      await execute("UPDATE contributions SET amount=?,paidAt=?,paymentMethod=?,reference=?,comment=? WHERE id=? AND tontineId=?",[money(input.amount),paidAt,input.paymentMethod,input.reference||null,input.comment||null,input.id,input.tontineId]);await audit(input.tontineId,ctx.user.id,"contribution",input.id,"corrected",{before:old,after:input,reason:input.reason},"corrected",input.amount,isDemo);return{success:true};
    }),
    reverse: protectedProcedure.input(groupInput.extend({id:z.number().int().positive(),reason:z.string().trim().min(3).max(500),confirmed:z.literal(true)})).mutation(async({input,ctx})=>{
      const {isDemo}=await access(ctx.user.id,input.tontineId,["admin"]);const r=await execute("UPDATE contributions SET status='reversed' WHERE id=? AND tontineId=? AND status='confirmed'",[input.id,input.tontineId]);if(!r.affectedRows)throw new TRPCError({code:"NOT_FOUND",message:"Cotisation introuvable ou déjà corrigée."});await audit(input.tontineId,ctx.user.id,"contribution",input.id,"reversed",{reason:input.reason},"reversed",undefined,isDemo);return{success:true};
    }),
  }),

  delays: protectedProcedure.input(groupInput).query(async({input,ctx})=>{
    const {role}=await access(ctx.user.id,input.tontineId);const own=role==="member"?await linkedMemberId(ctx.user.id,input.tontineId):null;const rows=await query("SELECT m.id,m.fullName,m.phone,m.expectedAmount,m.frequency,m.joinedAt,m.status,t.customDueDates,COALESCE(c.paid,0) AS paid FROM members m JOIN tontines t ON t.id=m.tontineId LEFT JOIN (SELECT memberId,SUM(amount) AS paid FROM contributions WHERE tontineId=? AND status='confirmed' GROUP BY memberId) c ON c.memberId=m.id WHERE m.tontineId=? AND m.status IN ('active','blocked') AND (? IS NULL OR m.id=?) ORDER BY m.fullName",[input.tontineId,input.tontineId,own,own]);
    const today=new Date();const startOfToday=Date.UTC(today.getFullYear(),today.getMonth(),today.getDate());
    return rows.map(m=>{const joined=new Date(`${String(m.joinedAt).slice(0,10)}T00:00:00Z`);const days=Math.max(0,Math.floor((startOfToday-Date.UTC(joined.getUTCFullYear(),joined.getUTCMonth(),joined.getUTCDate()))/86400000));const freq=String(m.frequency);let dueCount=freq==="daily"?days+1:freq==="weekly"?Math.floor(days/7)+1:freq==="monthly"?Math.max(1,(today.getFullYear()-joined.getFullYear())*12+today.getMonth()-joined.getMonth()+1):0;let nextDue=new Date(joined);if(freq==="daily")nextDue.setUTCDate(nextDue.getUTCDate()+dueCount);else if(freq==="weekly")nextDue.setUTCDate(nextDue.getUTCDate()+dueCount*7);else if(freq==="monthly")nextDue.setUTCMonth(nextDue.getUTCMonth()+dueCount);else{const dates=String(m.customDueDates||"").split(",").map(d=>d.trim()).filter(d=>/^\d{4}-\d{2}-\d{2}$/.test(d));const past=dates.filter(d=>Date.parse(`${d}T00:00:00Z`)<startOfToday);dueCount=past.length;const upcoming=dates.find(d=>Date.parse(`${d}T00:00:00Z`)>=startOfToday);if(upcoming)nextDue=new Date(`${upcoming}T00:00:00Z`);}
      const expected=dueCount*Number(m.expectedAmount);const paid=Number(m.paid);const remaining=Math.max(0,expected-paid);const paidCycles=Math.floor(paid/Math.max(1,Number(m.expectedAmount)));const missed=Math.max(0,dueCount-paidCycles);let overdueDays=0;if(missed>0){const firstMiss= new Date(joined);if(freq==="daily")firstMiss.setUTCDate(firstMiss.getUTCDate()+paidCycles);else if(freq==="weekly")firstMiss.setUTCDate(firstMiss.getUTCDate()+paidCycles*7);else if(freq==="monthly")firstMiss.setUTCMonth(firstMiss.getUTCMonth()+paidCycles);else{const dates=String(m.customDueDates||"").split(",").filter(Boolean);if(dates[paidCycles])firstMiss.setTime(Date.parse(`${dates[paidCycles]}T00:00:00Z`));}overdueDays=Math.max(0,Math.floor((startOfToday-Date.UTC(firstMiss.getUTCFullYear(),firstMiss.getUTCMonth(),firstMiss.getUTCDate()))/86400000));}
      return{id:m.id,fullName:m.fullName,phone:m.phone,expected,paid,remaining,overdueDays,nextDueDate:nextDue.toISOString().slice(0,10),status:m.status};}).filter(r=>r.remaining>0).sort((a,b)=>b.overdueDays-a.overdueDays);
  }),

  turns: router({
    list: protectedProcedure.input(groupInput).query(async({input,ctx})=>{const{role}=await access(ctx.user.id,input.tontineId);if(role==="member"){const own=await linkedMemberId(ctx.user.id,input.tontineId);return query("SELECT t.*,m.fullName,m.phone,p.status AS payoutStatus,p.amount AS payoutAmount,p.paidAt AS payoutDate FROM beneficiary_turns t JOIN members m ON m.id=t.memberId LEFT JOIN payouts p ON p.turnId=t.id WHERE t.tontineId=? AND t.memberId=? ORDER BY t.position",[input.tontineId,own]);}return query("SELECT t.*,m.fullName,m.phone,p.status AS payoutStatus,p.amount AS payoutAmount,p.paidAt AS payoutDate FROM beneficiary_turns t JOIN members m ON m.id=t.memberId LEFT JOIN payouts p ON p.turnId=t.id WHERE t.tontineId=? ORDER BY t.position",[input.tontineId]);}),
    add: protectedProcedure.input(groupInput.extend({memberId:z.number().int().positive(),plannedDate:z.string(),plannedAmount:z.number().int().positive().max(1_000_000_000)})).mutation(async({input,ctx})=>{const{isDemo}=await access(ctx.user.id,input.tontineId,["admin"]);await assertMemberInGroup(input.memberId,input.tontineId);const[rows]=await Promise.all([query("SELECT COALESCE(MAX(position),0)+1 AS p FROM beneficiary_turns WHERE tontineId=?",[input.tontineId])]);const pos=Number(rows[0]?.p??1);const r=await execute("INSERT INTO beneficiary_turns (tontineId,memberId,position,plannedDate,plannedAmount,isDemo) VALUES (?,?,?,?,?,?)",[input.tontineId,input.memberId,pos,localDate(input.plannedDate),money(input.plannedAmount),isDemo?1:0]);await audit(input.tontineId,ctx.user.id,"turn",r.insertId,"created",{position:pos,memberId:input.memberId},"planned",input.plannedAmount,isDemo);return{id:r.insertId};}),
    reorder: protectedProcedure.input(groupInput.extend({orderedIds:z.array(z.number().int().positive()).min(1),confirmed:z.boolean()})).mutation(async({input,ctx})=>{const{isDemo}=await access(ctx.user.id,input.tontineId,["admin"]);await withTransaction(async conn=>{const[all]=await conn.execute("SELECT id,position,status FROM beneficiary_turns WHERE tontineId=? FOR UPDATE",[input.tontineId]);const turns=all as {id:number;position:number;status:string}[];if(turns.length!==input.orderedIds.length||new Set(input.orderedIds).size!==turns.length||turns.some(t=>!input.orderedIds.includes(t.id)))throw new TRPCError({code:"BAD_REQUEST",message:"La liste doit contenir chaque tour de cette tontine une seule fois."});if(turns.some(t=>t.status==="paid")&&!input.confirmed)throw new TRPCError({code:"PRECONDITION_FAILED",message:"Confirmation requise après un paiement."});await conn.execute("UPDATE beneficiary_turns SET position=position+100000 WHERE tontineId=?",[input.tontineId]);for(let i=0;i<input.orderedIds.length;i++)await conn.execute("UPDATE beneficiary_turns SET position=? WHERE id=? AND tontineId=?",[i+1,input.orderedIds[i],input.tontineId]);});await audit(input.tontineId,ctx.user.id,"turn_order",null,"reordered",{orderedIds:input.orderedIds},"updated",undefined,isDemo);return{success:true};}),
    update: protectedProcedure.input(groupInput.extend({id:z.number().int().positive(),plannedDate:z.string(),plannedAmount:z.number().int().positive().max(1_000_000_000)})).mutation(async({input,ctx})=>{const{isDemo}=await access(ctx.user.id,input.tontineId,["admin"]);const r=await execute("UPDATE beneficiary_turns SET plannedDate=?,plannedAmount=? WHERE id=? AND tontineId=? AND status='planned'",[localDate(input.plannedDate),money(input.plannedAmount),input.id,input.tontineId]);if(!r.affectedRows)throw new TRPCError({code:"NOT_FOUND",message:"Tour introuvable ou déjà payé."});await audit(input.tontineId,ctx.user.id,"turn",input.id,"updated",{plannedDate:input.plannedDate,plannedAmount:input.plannedAmount},"planned",input.plannedAmount,isDemo);return{success:true};}),
  }),

  payouts: router({
    list: protectedProcedure.input(groupInput.extend({status:z.enum(["pending","paid","cancelled"]).optional()})).query(async({input,ctx})=>{const{role}=await access(ctx.user.id,input.tontineId);let sql="SELECT p.*,m.fullName,t.position,t.plannedDate,t.plannedAmount AS expected,u.name AS actorName FROM payouts p JOIN members m ON m.id=p.memberId JOIN beneficiary_turns t ON t.id=p.turnId JOIN users u ON u.id=p.createdBy WHERE p.tontineId=?";const args:unknown[]=[input.tontineId];if(role==="member"){sql+=" AND p.memberId=?";args.push(await linkedMemberId(ctx.user.id,input.tontineId));}if(input.status){sql+=" AND p.status=?";args.push(input.status);}sql+=" ORDER BY p.createdAt DESC LIMIT 300";return query(sql,args);}),
    create: protectedProcedure.input(groupInput.extend({turnId:z.number().int().positive(),amount:z.number().int().positive().max(1_000_000_000),paymentMethod:methods,reference:z.string().max(120).optional(),comment:z.string().max(1000).optional()})).mutation(async({input,ctx})=>{const{isDemo}=await access(ctx.user.id,input.tontineId,["admin","treasurer"]);const[turn]=await query("SELECT id,memberId,status,plannedAmount FROM beneficiary_turns WHERE id=? AND tontineId=?",[input.turnId,input.tontineId]);if(!turn)throw new TRPCError({code:"NOT_FOUND",message:"Tour introuvable."});if(turn.status==="paid")throw new TRPCError({code:"CONFLICT",message:"Ce tour est déjà payé."});const[r]=await query("SELECT id,status FROM payouts WHERE turnId=?",[input.turnId]);if(r&&r.status!=="cancelled")throw new TRPCError({code:"CONFLICT",message:"Un paiement existe déjà pour ce tour."});await execute("UPDATE payouts SET amount=?,paymentMethod=?,reference=?,comment=?,status='pending',paidAt=NULL,createdBy=?,updatedAt=CURRENT_TIMESTAMP WHERE turnId=? AND status='cancelled'",[money(input.amount),input.paymentMethod,input.reference||null,input.comment||null,ctx.user.id,input.turnId]);const existing=await query("SELECT id FROM payouts WHERE turnId=?",[input.turnId]);let id=Number(existing[0]?.id);if(!id){const result=await execute("INSERT INTO payouts (tontineId,turnId,memberId,amount,paymentMethod,reference,comment,status,isDemo,createdBy) VALUES (?,?,?,?,?,?,?,'pending',?,?)",[input.tontineId,input.turnId,turn.memberId,money(input.amount),input.paymentMethod,input.reference||null,input.comment||null,isDemo?1:0,ctx.user.id]);id=result.insertId;}await audit(input.tontineId,ctx.user.id,"payout",id,"prepared",{turnId:input.turnId,memberId:turn.memberId},"pending",input.amount,isDemo);return{id};}),
    setStatus: protectedProcedure.input(groupInput.extend({id:z.number().int().positive(),status:z.enum(["paid","cancelled"]),paidAt:z.string().optional(),confirmed:z.literal(true),reason:z.string().trim().min(3).max(500).optional()})).mutation(async({input,ctx})=>{const{isDemo}=await access(ctx.user.id,input.tontineId,["admin","treasurer"]);const[old]=await query("SELECT * FROM payouts WHERE id=? AND tontineId=?",[input.id,input.tontineId]);if(!old)throw new TRPCError({code:"NOT_FOUND",message:"Paiement introuvable."});if(old.status==="cancelled")throw new TRPCError({code:"CONFLICT",message:"Ce paiement est déjà annulé."});if(old.status==="paid"&&input.status==="paid")throw new TRPCError({code:"CONFLICT",message:"Ce paiement est déjà marqué comme payé."});if(input.status==="cancelled"&&!input.reason)throw new TRPCError({code:"BAD_REQUEST",message:"Motif d’annulation obligatoire."});await withTransaction(async conn=>{const[locked]=await conn.execute("SELECT status FROM payouts WHERE id=? AND tontineId=? FOR UPDATE",[input.id,input.tontineId]);const current=(locked as {status:string}[])[0];if(!current||current.status==="cancelled"||(input.status==="paid"&&current.status==="paid"))throw new TRPCError({code:"CONFLICT",message:"Le statut du paiement a changé. Actualisez la page."});if(input.status==="paid"){const[turnRows]=await conn.execute("SELECT status FROM beneficiary_turns WHERE id=? AND tontineId=? FOR UPDATE",[old.turnId,input.tontineId]);if((turnRows as {status:string}[])[0]?.status==="paid")throw new TRPCError({code:"CONFLICT",message:"Le tour est déjà réglé."});}await conn.execute("UPDATE payouts SET status=?,paidAt=?,updatedAt=CURRENT_TIMESTAMP WHERE id=? AND tontineId=?",[input.status,input.status==="paid"?(input.paidAt?new Date(input.paidAt):new Date()):null,input.id,input.tontineId]);await conn.execute("UPDATE beneficiary_turns SET status=?,paidAt=? WHERE id=? AND tontineId=?",[input.status==="paid"?"paid":"planned",input.status==="paid"?(input.paidAt?new Date(input.paidAt):new Date()):null,old.turnId,input.tontineId]);});await audit(input.tontineId,ctx.user.id,"payout",input.id,input.status==="paid"?"paid":"cancelled",{before:old,reason:input.reason||null},input.status,Number(old.amount),isDemo);return{success:true};}),
  }),

  history: protectedProcedure.input(groupInput.extend({entityType:z.string().max(48).optional(),status:z.string().max(32).optional(),memberId:z.number().int().positive().optional(),from:z.string().optional(),to:z.string().optional()})).query(async({input,ctx})=>{const{role}=await access(ctx.user.id,input.tontineId);let sql="SELECT a.*,u.name AS actorName,m.fullName FROM audit_logs a JOIN users u ON u.id=a.actorId LEFT JOIN members m ON a.entityType='member' AND CAST(a.entityId AS UNSIGNED)=m.id WHERE a.tontineId=?";const args:unknown[]=[input.tontineId];if(role==="member"){const own=await linkedMemberId(ctx.user.id,input.tontineId);sql+=" AND (a.actorId=? OR a.entityId=? OR JSON_UNQUOTE(JSON_EXTRACT(a.details,'$.memberId'))=?)";args.push(ctx.user.id,String(own),String(own));}if(input.entityType){sql+=" AND a.entityType=?";args.push(input.entityType);}if(input.status){sql+=" AND a.status=?";args.push(input.status);}if(input.memberId){if(role==="member"&&input.memberId!==await linkedMemberId(ctx.user.id,input.tontineId))throw new TRPCError({code:"FORBIDDEN",message:"Filtre membre non autorisé."});sql+=" AND (a.entityId=? OR JSON_UNQUOTE(JSON_EXTRACT(a.details,'$.memberId'))=?)";args.push(String(input.memberId),String(input.memberId));}if(input.from){sql+=" AND a.createdAt>=?";args.push(`${localDate(input.from)} 00:00:00`);}if(input.to){sql+=" AND a.createdAt<=?";args.push(`${localDate(input.to)} 23:59:59`);}sql+=" ORDER BY a.createdAt DESC LIMIT 500";return query(sql,args);}),

  settings: router({
    get:protectedProcedure.input(groupInput).query(async({input,ctx})=>{await access(ctx.user.id,input.tontineId,["admin","treasurer"]);const[g]=await query("SELECT * FROM tontines WHERE id=?",[input.tontineId]);const admins=await query("SELECT u.id,u.name,u.email,u.phone,m.role FROM tontine_memberships m JOIN users u ON u.id=m.userId WHERE m.tontineId=? ORDER BY FIELD(m.role,'admin','treasurer','member'),u.name",[input.tontineId]);return{...g,admins};}),
    update:protectedProcedure.input(groupInput.extend({name:z.string().trim().min(2).max(160),description:z.string().max(3000).optional(),contributionAmount:z.number().int().min(0).max(1_000_000_000),frequency:frequencies,customDueDates:z.array(z.string()).max(100),lateDays:z.number().int().min(0).max(365),blockDays:z.number().int().min(0).max(3650),threshold:z.number().int().positive().max(1_000_000_000)})).mutation(async({input,ctx})=>{const{isDemo}=await access(ctx.user.id,input.tontineId,["admin"]);const dates=input.customDueDates.map(localDate);const[old]=await query("SELECT * FROM tontines WHERE id=?",[input.tontineId]);await execute("UPDATE tontines SET name=?,description=?,contributionAmount=?,frequency=?,customDueDates=?,lateDays=?,blockDays=?,threshold=? WHERE id=?",[input.name,input.description||null,input.contributionAmount,input.frequency,dates.join(","),input.lateDays,input.blockDays,input.threshold,input.tontineId]);await audit(input.tontineId,ctx.user.id,"settings",input.tontineId,"updated",{before:old,after:input},"updated",undefined,isDemo);return{success:true};}),
  }),
});

function cryptoRandom(){return randomBytes(8).toString("hex");}

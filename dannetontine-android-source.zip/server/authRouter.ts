import { createHash } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { execute, query } from "./appDb";
import {
  clearSessionCookie, createDemoTontine, createLocalAccount, deleteDemoTontine, hashPassword,
  hasLocalAccount, issueSession, normalizeIdentifier, registerFirstAdmin,
  revokeSession, verifyPassword,
} from "./localAuth";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

const identifierSchema = z.string().trim().min(5).max(320);
const passwordSchema = z.string().min(10).max(128);

async function assertTontineAdmin(userId: number, tontineId: number) {
  const rows = await query("SELECT id FROM tontine_memberships WHERE tontineId = ? AND userId = ? AND role = 'admin' LIMIT 1", [tontineId, userId]);
  if (!rows.length) throw new TRPCError({ code: "FORBIDDEN", message: "Action réservée à l’administrateur de cette tontine." });
}

export const authRouter = router({
  setupStatus: publicProcedure.query(async () => ({ setupRequired: !(await hasLocalAccount()) })),

  me: protectedProcedure.query(async ({ ctx }) => {
    const groups = await query("SELECT t.id, t.name, t.isDemo, m.role FROM tontine_memberships m JOIN tontines t ON t.id = m.tontineId WHERE m.userId = ? ORDER BY t.isDemo, t.name", [ctx.user.id]);
    return { id: ctx.user.id, name: ctx.user.name, email: ctx.user.email, phone: ctx.user.phone, groups };
  }),

  setup: publicProcedure.input(z.object({
    name: z.string().trim().min(2).max(160), identifier: identifierSchema, password: passwordSchema,
    tontineName: z.string().trim().min(2).max(160), contributionAmount: z.number().int().min(0).max(1_000_000_000),
    frequency: z.enum(["daily", "weekly", "monthly", "custom"]),
  })).mutation(async ({ input, ctx }) => {
    if (await hasLocalAccount()) throw new TRPCError({ code: "FORBIDDEN", message: "La première configuration est déjà terminée." });
    try { return await registerFirstAdmin(input, ctx.res, ctx.req); }
    catch (error) { throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Configuration impossible." }); }
  }),

  login: publicProcedure.input(z.object({ identifier: identifierSchema, password: z.string().min(1).max(128) })).mutation(async ({ input, ctx }) => {
    const identifier = normalizeIdentifier(input.identifier);
    const keyHash = createHash("sha256").update(`login:${identifier}`).digest("hex");
    const attempts = await query("SELECT attempts, lockedUntil FROM auth_attempts WHERE keyHash = ? LIMIT 1", [keyHash]);
    if (attempts[0]?.lockedUntil && new Date(attempts[0].lockedUntil as string).getTime() > Date.now()) {
      throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Trop de tentatives. Réessayez plus tard." });
    }
    const rows = await query("SELECT id, passwordHash FROM users WHERE loginMethod = 'password' AND loginIdentifier = ? LIMIT 1", [identifier]);
    const user = rows[0];
    const valid = user ? await verifyPassword(input.password, user.passwordHash as string | null) : await verifyPassword(input.password, null);
    if (!user || !valid) {
      await execute(
        `INSERT INTO auth_attempts (keyHash, attempts, windowStartedAt, lockedUntil) VALUES (?, 1, CURRENT_TIMESTAMP, NULL)
         ON DUPLICATE KEY UPDATE attempts = IF(windowStartedAt < DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 15 MINUTE), 1, attempts + 1),
         lockedUntil = IF(attempts >= 7, DATE_ADD(CURRENT_TIMESTAMP, INTERVAL 15 MINUTE), NULL),
         windowStartedAt = IF(windowStartedAt < DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 15 MINUTE), CURRENT_TIMESTAMP, windowStartedAt)`,
        [keyHash],
      );
      throw new TRPCError({ code: "UNAUTHORIZED", message: "Identifiant ou mot de passe incorrect." });
    }
    await execute("DELETE FROM auth_attempts WHERE keyHash = ?", [keyHash]);
    await issueSession(Number(user.id), ctx.res, ctx.req);
    return { success: true };
  }),

  logout: publicProcedure.mutation(async ({ ctx }) => {
    await revokeSession(ctx.req, ctx.res);
    return { success: true };
  }),

  createAccess: protectedProcedure.input(z.object({
    tontineId: z.number().int().positive(), name: z.string().trim().min(2).max(160),
    identifier: identifierSchema, password: passwordSchema, role: z.enum(["admin", "treasurer", "member"]),
  })).mutation(async ({ input, ctx }) => {
    try {
      await assertTontineAdmin(ctx.user.id, input.tontineId);
      const userId = await createLocalAccount(input);
      return { success: true, userId };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Création de l’accès impossible.";
      throw new TRPCError({ code: message.includes("refusé") ? "FORBIDDEN" : "BAD_REQUEST", message });
    }
  }),

  createDemo: protectedProcedure.input(z.object({ tontineId: z.number().int().positive() })).mutation(async ({ input, ctx }) => {
    await assertTontineAdmin(ctx.user.id, input.tontineId);
    const id = await createDemoTontine(ctx.user.id);
    return { id };
  }),

  deleteDemo: protectedProcedure.input(z.object({ tontineId: z.number().int().positive(), confirmation: z.literal("SUPPRIMER LA DÉMO") })).mutation(async ({ input, ctx }) => {
    await assertTontineAdmin(ctx.user.id, input.tontineId);
    await deleteDemoTontine(ctx.user.id, input.tontineId);
    return { success: true };
  }),

  setAccessRole: protectedProcedure.input(z.object({tontineId:z.number().int().positive(),userId:z.number().int().positive(),role:z.enum(["admin","treasurer","member"])})).mutation(async({input,ctx})=>{
    await assertTontineAdmin(ctx.user.id,input.tontineId);
    const rows=await query("SELECT role FROM tontine_memberships WHERE tontineId=? AND userId=? LIMIT 1",[input.tontineId,input.userId]);
    if(!rows.length)throw new TRPCError({code:"NOT_FOUND",message:"Accès introuvable dans cette tontine."});
    if(rows[0].role==="admin"&&input.role!=="admin"){
      const admins=await query("SELECT COUNT(*) AS count FROM tontine_memberships WHERE tontineId=? AND role='admin'",[input.tontineId]);
      if(Number(admins[0]?.count??0)<=1)throw new TRPCError({code:"PRECONDITION_FAILED",message:"La tontine doit conserver au moins un administrateur."});
    }
    await execute("UPDATE tontine_memberships SET role=? WHERE tontineId=? AND userId=?",[input.role,input.tontineId,input.userId]);
    await execute("INSERT INTO audit_logs (tontineId,actorId,entityType,entityId,action,details,status) VALUES (?,?, 'access', ?, 'role_changed', ?, ?)",[input.tontineId,ctx.user.id,String(input.userId),JSON.stringify({from:rows[0].role,to:input.role}),input.role]);
    return {success:true};
  }),

  resetAccessPassword: protectedProcedure.input(z.object({tontineId:z.number().int().positive(),userId:z.number().int().positive(),newPassword:passwordSchema})).mutation(async({input,ctx})=>{
    await assertTontineAdmin(ctx.user.id,input.tontineId);
    const rows=await query("SELECT u.loginMethod FROM users u JOIN tontine_memberships m ON m.userId=u.id WHERE m.tontineId=? AND m.userId=? LIMIT 1",[input.tontineId,input.userId]);
    if(!rows.length)throw new TRPCError({code:"NOT_FOUND",message:"Compte introuvable dans cette tontine."});
    if(rows[0].loginMethod!=="password")throw new TRPCError({code:"PRECONDITION_FAILED",message:"Ce compte n'utilise pas l'authentification locale."});
    await execute("UPDATE users SET passwordHash=? WHERE id=?",[await hashPassword(input.newPassword),input.userId]);
    await execute("UPDATE auth_sessions SET revokedAt=CURRENT_TIMESTAMP WHERE userId=? AND revokedAt IS NULL",[input.userId]);
    await execute("INSERT INTO audit_logs (tontineId,actorId,entityType,entityId,action,details,status) VALUES (?,?, 'access', ?, 'password_reset', ?, 'updated')",[input.tontineId,ctx.user.id,String(input.userId),JSON.stringify({targetUserId:input.userId})]);
    return {success:true};
  }),

  changePassword: protectedProcedure.input(z.object({ currentPassword: z.string().min(1).max(128), newPassword: passwordSchema })).mutation(async ({ input, ctx }) => {
    const rows = await query("SELECT passwordHash FROM users WHERE id = ? LIMIT 1", [ctx.user.id]);
    if (!await verifyPassword(input.currentPassword, rows[0]?.passwordHash as string | null)) {
      throw new TRPCError({ code: "UNAUTHORIZED", message: "Mot de passe actuel incorrect." });
    }
    const { hashPassword } = await import("./localAuth");
    const passwordHash = await hashPassword(input.newPassword);
    await execute("UPDATE users SET passwordHash = ? WHERE id = ?", [passwordHash, ctx.user.id]);
    await execute("UPDATE auth_sessions SET revokedAt = CURRENT_TIMESTAMP WHERE userId = ?", [ctx.user.id]);
    await issueSession(ctx.user.id, ctx.res, ctx.req);
    return { success: true };
  }),
});

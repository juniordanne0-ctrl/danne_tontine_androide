import { createHash, randomBytes, scrypt as scryptCallback, timingSafeEqual, randomUUID } from "node:crypto";
import type { RowDataPacket } from "mysql2/promise";
import type { Request, Response } from "express";
import { parse } from "cookie";
import { execute, query, withTransaction } from "./appDb";

const scrypt = (password: string, salt: Buffer, length: number, options?: { N?: number; r?: number; p?: number; maxmem?: number }) => new Promise<Buffer>((resolve, reject) => {
  scryptCallback(password, salt, length, options ?? {}, (error, derived) => error ? reject(error) : resolve(derived as Buffer));
});
export const SESSION_COOKIE = "webdev_app_session";
const SESSION_DAYS = 7;
const PASSWORD_MIN = 10;
const PASSWORD_MAX = 128;

export type LocalUser = {
  id: number;
  openId: string;
  name: string | null;
  email: string | null;
  phone: string | null;
  loginMethod: string | null;
  role: "user" | "admin";
  lastSignedIn: Date;
};

export function normalizeIdentifier(input: string) {
  const value = input.trim();
  return value.includes("@") ? value.toLowerCase() : value.replace(/[\s().-]/g, "");
}

export function normalizePhone(input: string) {
  const compact = input.trim().replace(/[\s().-]/g, "");
  if (!/^\+?[0-9]{7,18}$/.test(compact)) throw new Error("Numéro de téléphone invalide.");
  if (compact.startsWith("+")) return compact;
  if (compact.startsWith("237") && compact.length === 12) return `+${compact}`;
  if (compact.length === 9) return `+237${compact}`;
  return `+${compact}`;
}

export function normalizeEmail(input: string) {
  const value = input.trim().toLowerCase();
  if (value.length > 320 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) throw new Error("Adresse courriel invalide.");
  return value;
}

export async function hashPassword(password: string) {
  if (password.length < PASSWORD_MIN || password.length > PASSWORD_MAX) {
    throw new Error(`Le mot de passe doit contenir entre ${PASSWORD_MIN} et ${PASSWORD_MAX} caractères.`);
  }
  const salt = randomBytes(16);
  const derived = await scrypt(password, salt, 64, { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }) as Buffer;
  return `scrypt$16384$8$1$${salt.toString("hex")}$${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, encoded: string | null) {
  if (!encoded) return false;
  const [algorithm, n, r, p, saltHex, hashHex] = encoded.split("$");
  if (algorithm !== "scrypt" || !saltHex || !hashHex) return false;
  try {
    const salt = Buffer.from(saltHex, "hex");
    const expected = Buffer.from(hashHex, "hex");
    if (salt.length !== 16 || expected.length !== 64) return false;
    const derived = await scrypt(password, salt, expected.length, {
      N: Number(n), r: Number(r), p: Number(p), maxmem: 64 * 1024 * 1024,
    }) as Buffer;
    return timingSafeEqual(expected, derived);
  } catch {
    return false;
  }
}

const sha256 = (value: string) => createHash("sha256").update(value).digest("hex");

function cookieOptions(req: Request) {
  const hostHeader = String(req.headers["x-forwarded-host"] ?? req.headers.host ?? "").split(",")[0].trim();
  const host = hostHeader.split(":")[0].replace(/^\[|\]$/g, "").toLowerCase();
  const forwarded = String(req.headers["x-forwarded-proto"] ?? "").split(",")[0].trim().toLowerCase();
  const localPlainHttp = ["localhost", "127.0.0.1", "::1"].includes(host) && forwarded !== "https";
  return { httpOnly: true, secure: !localPlainHttp, sameSite: localPlainHttp ? "lax" as const : "none" as const, path: "/", maxAge: SESSION_DAYS * 24 * 60 * 60 * 1000 };
}

export function setSessionCookie(res: Response, token: string, req: Request) {
  res.cookie(SESSION_COOKIE, token, {
    ...cookieOptions(req),
  });
}

export function clearSessionCookie(res: Response, req: Request) {
  const { maxAge: _maxAge, ...options } = cookieOptions(req);
  res.clearCookie(SESSION_COOKIE, options);
}

export async function issueSession(userId: number, res: Response, req: Request) {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await execute("INSERT INTO auth_sessions (userId, tokenHash, expiresAt) VALUES (?, ?, ?)", [userId, sha256(token), expiresAt]);
  await execute("UPDATE users SET lastSignedIn = CURRENT_TIMESTAMP WHERE id = ?", [userId]);
  setSessionCookie(res, token, req);
}

export async function revokeSession(req: Request, res: Response) {
  const token = parse(req.headers.cookie ?? "")[SESSION_COOKIE];
  if (token) await execute("UPDATE auth_sessions SET revokedAt = CURRENT_TIMESTAMP WHERE tokenHash = ? AND revokedAt IS NULL", [sha256(token)]);
  clearSessionCookie(res, req);
}

export async function authenticateLocalRequest(req: Request): Promise<LocalUser | null> {
  const token = parse(req.headers.cookie ?? "")[SESSION_COOKIE];
  if (!token || token.length > 128) return null;
  const rows = await query<LocalUser & RowDataPacket>(
    `SELECT u.id, u.openId, u.name, u.email, u.phone, u.loginMethod, u.role, u.lastSignedIn
     FROM auth_sessions s JOIN users u ON u.id = s.userId
     WHERE s.tokenHash = ? AND s.revokedAt IS NULL AND s.expiresAt > CURRENT_TIMESTAMP LIMIT 1`,
    [sha256(token)],
  );
  return rows[0] ?? null;
}

export async function hasLocalAccount() {
  const rows = await query<RowDataPacket & { count: number }>("SELECT COUNT(*) AS count FROM users WHERE loginMethod = 'password'");
  return Number(rows[0]?.count ?? 0) > 0;
}

export async function registerFirstAdmin(input: {
  name: string; identifier: string; password: string; tontineName: string; contributionAmount: number; frequency: string;
}, res: Response, req: Request) {
  const name = input.name.trim().slice(0, 160);
  if (name.length < 2) throw new Error("Saisissez un nom d'au moins 2 caractères.");
  const ident = normalizeIdentifier(input.identifier);
  const isEmail = ident.includes("@");
  const email = isEmail ? normalizeEmail(ident) : null;
  const phone = isEmail ? null : normalizePhone(ident);
  const passwordHash = await hashPassword(input.password);
  const tontineName = input.tontineName.trim().slice(0, 160);
  if (!tontineName) throw new Error("Le nom de la tontine est obligatoire.");
  const contributionAmount = Math.round(Number(input.contributionAmount));
  if (!Number.isSafeInteger(contributionAmount) || contributionAmount < 0) throw new Error("Montant de cotisation invalide.");

  const userId = await withTransaction(async conn => {
    const [users] = await conn.execute("SELECT id FROM users WHERE loginMethod = 'password' FOR UPDATE");
    if ((users as unknown[]).length > 0) throw new Error("Le compte administrateur initial existe déjà. Demandez à un administrateur de créer votre accès.");
    const openId = `local_${randomUUID()}`;
    const [userResult] = await conn.execute(
      "INSERT INTO users (openId, name, email, phone, loginIdentifier, loginMethod, passwordHash, initialAdmin, role, lastSignedIn) VALUES (?, ?, ?, ?, ?, 'password', ?, 'Y', 'admin', CURRENT_TIMESTAMP)",
      [openId, name, email, phone, ident, passwordHash],
    );
    const id = Number((userResult as { insertId: number }).insertId);
    const [groupResult] = await conn.execute(
      "INSERT INTO tontines (name, contributionAmount, frequency) VALUES (?, ?, ?)",
      [tontineName, contributionAmount, ["daily", "weekly", "monthly", "custom"].includes(input.frequency) ? input.frequency : "monthly"],
    );
    await conn.execute("INSERT INTO tontine_memberships (tontineId, userId, role) VALUES (?, ?, 'admin')", [Number((groupResult as { insertId: number }).insertId), id]);
    return id;
  });
  await issueSession(userId, res, req);
  return { success: true };
}

export async function createLocalAccount(input: {
  name: string; identifier: string; password: string; tontineId: number; role: "admin" | "treasurer" | "member";
}) {
  const name = input.name.trim().slice(0, 160);
  const ident = normalizeIdentifier(input.identifier);
  const email = ident.includes("@") ? normalizeEmail(ident) : null;
  const phone = email ? null : normalizePhone(ident);
  const passwordHash = await hashPassword(input.password);
  return withTransaction(async conn => {
    const [access] = await conn.execute("SELECT id FROM tontine_memberships WHERE tontineId = ? AND role = 'admin' FOR UPDATE", [input.tontineId]);
    if (!(access as unknown[]).length) throw new Error("Accès administrateur refusé.");
    const [result] = await conn.execute(
      "INSERT INTO users (openId, name, email, phone, loginIdentifier, loginMethod, passwordHash, role, lastSignedIn) VALUES (?, ?, ?, ?, ?, 'password', ?, 'user', CURRENT_TIMESTAMP)",
      [`local_${randomUUID()}`, name, email, phone, ident, passwordHash],
    );
    const userId = Number((result as { insertId: number }).insertId);
    await conn.execute("INSERT INTO tontine_memberships (tontineId, userId, role) VALUES (?, ?, ?)", [input.tontineId, userId, input.role]);
    if (phone) await conn.execute("UPDATE members SET linkedUserId = ? WHERE tontineId = ? AND phone = ? AND linkedUserId IS NULL", [userId, input.tontineId, phone]);
    return userId;
  });
}

export async function createDemoTontine(userId: number) {
  return withTransaction(async conn => {
    const [existing] = await conn.execute("SELECT id FROM tontines WHERE isDemo = 1 AND id IN (SELECT tontineId FROM tontine_memberships WHERE userId = ?)", [userId]);
    if ((existing as unknown[]).length) throw new Error("Une tontine de démonstration existe déjà.");
    const [g] = await conn.execute("INSERT INTO tontines (name, description, contributionAmount, frequency, isDemo) VALUES ('Démonstration DANNE', 'Données fictives isolées — ne pas utiliser comme données financières réelles.', 10000, 'monthly', 1)");
    const groupId = Number((g as { insertId: number }).insertId);
    await conn.execute("INSERT INTO tontine_memberships (tontineId, userId, role) VALUES (?, ?, 'admin')", [groupId, userId]);
    const samples = [
      ["Aïcha Ndom", "+237690000101"], ["Samuel Tchoumi", "+237690000102"], ["Clarisse Mballa", "+237690000103"],
    ];
    for (let i = 0; i < samples.length; i++) {
      const [m] = await conn.execute("INSERT INTO members (publicId,tontineId,fullName,phone,joinedAt,expectedAmount,frequency,status,isDemo) VALUES (?,?,?,?,CURDATE(),10000,'monthly',?,1)", [`DEMO-${i + 1}`, groupId, samples[i][0], samples[i][1], i === 2 ? "blocked" : "active"]);
      const memberId = Number((m as { insertId: number }).insertId);
      await conn.execute("INSERT INTO beneficiary_turns (tontineId,memberId,position,plannedDate,plannedAmount,isDemo) VALUES (?,?,?,DATE_ADD(CURDATE(), INTERVAL ? DAY),30000,1)", [groupId, memberId, i + 1, i * 30]);
      await conn.execute("INSERT INTO contributions (tontineId,memberId,amount,paidAt,paymentMethod,comment,status,isManual,isDemo,createdBy) VALUES (?,?,10000,DATE_SUB(CURRENT_TIMESTAMP, INTERVAL ? DAY),'cash','Exemple de démonstration','confirmed',1,1,?)", [groupId, memberId, i * 8, userId]);
    }
    await conn.execute("INSERT INTO audit_logs (tontineId,actorId,entityType,action,details,status,isDemo) VALUES (?,?,'demo','created','Espace de démonstration isolé','active',1)", [groupId, userId]);
    return groupId;
  });
}

export async function deleteDemoTontine(userId: number, tontineId: number) {
  return withTransaction(async conn => {
    const [groups] = await conn.execute("SELECT id FROM tontines WHERE id = ? AND isDemo = 1 AND id IN (SELECT tontineId FROM tontine_memberships WHERE userId = ? AND role = 'admin') FOR UPDATE", [tontineId, userId]);
    if (!(groups as unknown[]).length) throw new Error("Suppression refusée : cet espace n'est pas une démo autorisée.");
    await conn.execute("DELETE FROM audit_logs WHERE tontineId = ? AND isDemo = 1", [tontineId]);
    await conn.execute("DELETE FROM payouts WHERE tontineId = ? AND isDemo = 1", [tontineId]);
    await conn.execute("DELETE FROM contributions WHERE tontineId = ? AND isDemo = 1", [tontineId]);
    await conn.execute("DELETE FROM beneficiary_turns WHERE tontineId = ? AND isDemo = 1", [tontineId]);
    await conn.execute("DELETE FROM members WHERE tontineId = ? AND isDemo = 1", [tontineId]);
    await conn.execute("DELETE FROM tontine_memberships WHERE tontineId = ?", [tontineId]);
    await conn.execute("DELETE FROM tontines WHERE id = ? AND isDemo = 1", [tontineId]);
  });
}

import { router } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";
import { authRouter } from "./authRouter";
import { tontineRouter } from "./tontineRouter";

export const appRouter = router({
  system: systemRouter,
  auth: authRouter,
  tontine: tontineRouter,
});

export type AppRouter = typeof appRouter;

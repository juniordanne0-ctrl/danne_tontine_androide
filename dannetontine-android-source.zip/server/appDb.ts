import mysql, { type Pool, type PoolConnection, type ResultSetHeader, type RowDataPacket } from "mysql2/promise";

let pool: Pool | null = null;

export function sqlPool(): Pool {
  if (!pool) {
    const uri = process.env.DATABASE_URL ?? process.env.DRIZZLE_DATABASE_URL;
    if (!uri) throw new Error("La base de données n'est pas configurée.");
    pool = mysql.createPool(uri);
  }
  return pool;
}

export async function query<T extends RowDataPacket = RowDataPacket>(statement: string, values: unknown[] = []): Promise<T[]> {
  const [rows] = await sqlPool().execute(statement, values);
  return rows as T[];
}

export async function execute(statement: string, values: unknown[] = []): Promise<ResultSetHeader> {
  const [result] = await sqlPool().execute(statement, values);
  return result as ResultSetHeader;
}

export async function withTransaction<T>(fn: (conn: PoolConnection) => Promise<T>): Promise<T> {
  const conn = await sqlPool().getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (error) {
    await conn.rollback();
    throw error;
  } finally {
    conn.release();
  }
}

import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "1mb" }));
  app.use(express.urlencoded({ limit: "1mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  // Browser mutations must originate from the app origin. Together with the
  // app's short-lived CSRF-aware session and JSON-only tRPC API, this rejects
  // cross-site form submissions even though Preview cookies use SameSite=None.
  app.use("/api/trpc", (req, res, next) => {
    if (req.method === "GET") return next();
    const forwardedHost=String(req.headers["x-forwarded-host"]??req.headers.host??"").split(",")[0].trim();
    const forwardedProto=String(req.headers["x-forwarded-proto"]??"").split(",")[0].trim();
    const localHost=/^(localhost|127\.0\.0\.1|\[?::1\]?)(:\d+)?$/i.test(forwardedHost);
    const expectedOrigin=`${forwardedProto|| (localHost?"http":"https")}://${forwardedHost}`;
    const origin=req.get("origin");
    if(req.get("sec-fetch-site")==="cross-site"||!origin||origin!==expectedOrigin){res.status(403).json({error:"Origine de requête refusée."});return;}
    next();
  });
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });

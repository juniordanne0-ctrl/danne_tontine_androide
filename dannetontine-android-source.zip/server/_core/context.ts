import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { LocalUser } from "../localAuth";
import { authenticateLocalRequest } from "../localAuth";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: LocalUser | null;
};

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  let user: LocalUser | null = null;
  try {
    user = await authenticateLocalRequest(opts.req);
  } catch (error) {
    // An unavailable DB must not turn into an authenticated or synthetic user.
    if (process.env.NODE_ENV !== "production") console.error("[Auth] Session lookup failed", error);
  }
  return { req: opts.req, res: opts.res, user };
}

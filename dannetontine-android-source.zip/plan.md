# DANNE TONTINE — plan d’implémentation

## Objectif et périmètre
Application Web de gestion de tontine, en français, destinée prioritairement au Cameroun et utilisable sur petit écran Android. La présente version est un outil de tenue de registres et de gestion de cycles: aucune intégration bancaire, MTN/Orange Money, SMS ou notification fournisseur n’est déclarée active sans configuration et test réels. Les mouvements Mobile Money sont enregistrés manuellement.

## Architecture retenue
- **Frontend**: React 19, TypeScript, Wouter, TanStack Query et tRPC; pages métier sans rechargement, composants de formulaire réutilisables, graphiques issus des résultats du serveur.
- **Backend**: Express + tRPC, validation Zod des saisies, contrôles de permission côté serveur pour chaque lecture/écriture; les vérifications client ne sont jamais la barrière de sécurité.
- **Persistance**: base MySQL gérée du projet, accessible uniquement par le serveur via Drizzle; migrations relationnelles versionnées, valeurs monétaires stockées en entiers XAF, transactions DB pour paiements, blocages et réordonnancement; dates et filtres cohérents pour le Cameroun. Aucune donnée métier finale dans localStorage.
- **Données**: comptes d’accès et sessions; tontines; rattachement des comptes aux tontines avec rôle; membres (profil), échéances/règles; tours bénéficiaires; cotisations; paiements; événements de blocage/réactivation; journal d’audit et marqueur de données de démo. Toutes les requêtes métier sont scellées à la tontine actuellement autorisée et les accès par identifiant sont revalidés sur le serveur.
- **Authentification locale** (choix de l’utilisateur): identifiant téléphone ou courriel normalisé + mot de passe. Mots de passe conservés uniquement sous forme de dérivé `scrypt` à sel aléatoire, comparaison à temps constant; session à jeton aléatoire dont seul le condensat est stocké en base, expiration et révocation, cookie `HttpOnly`, `Secure`, `SameSite=None` pour l’aperçu HTTPS intégré. Limitation des essais de connexion, réponses d’erreur non révélatrices, protections CSRF pour les mutations. Premier compte créé par l’assistant de première configuration; après cette étape, création/rattachement de comptes sous contrôle d’un administrateur. Aucun OTP/SMS/courriel de récupération ne sera simulé; une réinitialisation est un flux administratif traçable tant qu’aucun fournisseur de vérification n’est configuré.
- **Rôles**: autorisations Administrateur, Trésorier et Membre rattachées à la tontine; membre ne lit que son profil et les informations autorisées. Trésorier limité aux saisies prévues; les réglages et changements de statut sont réservés à l’administrateur.
- **Flux financiers**: écriture financière non supprimée; correction/annulation par opération compensatrice, motif et audit; paiement `en attente/payé/annulé`, seul `payé` entre dans les sorties du solde, un seul paiement effectif par tour; confirmations explicites avant tout paiement et toute annulation. Détection d’un doublon probable (membre, montant, date, référence) et refus/confirmation renforcée au lieu d’une double saisie silencieuse.
- **Retards**: échéances générées ou interprétées à partir de la fréquence, date de départ et paramètres de tontine; comparaison aux cotisations réellement créditées, montant restant et jours de retard calculés côté serveur. Les changements de paramètres s’appliquent aux échéances futures et ne réécrivent pas les mouvements passés.
- **Démonstration**: une tontine de démonstration optionnelle et explicitement étiquetée, lignes marquées par un indicateur de démo et filtrées hors des données réelles; action de retrait limitée aux lignes de démo avec aperçu du nombre de lignes, confirmation et refus si une ligne réelle serait touchée. Aucune fausse statistique injectée dans le tableau vide réel.
- **Exports**: CSV généré à partir des filtres et données persistées; rapport imprimable optimisé A4/mobile et export PDF via impression/enregistrement PDF du navigateur, sans service externe.

## Découpage des pages
1. Connexion et première configuration du compte administrateur.
2. Tableau de bord: encaissé, versé, solde, membres actifs/en retard/bloqués, attendu, prochain bénéficiaire et derniers mouvements; vues de cotisations et paiements agrégées depuis MySQL.
3. Membres et fiche membre: création, édition, recherche nom/téléphone, filtres de statut, historique et désactivation/archivage conservant les finances.
4. Cotisations: ajout manuel, choix du mode/date/référence, historique et filtres, correction tracée.
5. Paiements: tours et montant prévu, montant payé, mode/référence/commentaire, statuts, confirmations et historique.
6. Retards et blocages: échéances calculées, montant payé/restant, jours et prochaine date; blocage/réactivation avec motif, date et historique.
7. Bénéficiaires: ordre, dates/montants prévus, tour courant/suivants, confirmation de paiement et historique non réécrit.
8. Historique et rapports: événements/audit centralisés, filtres, téléchargement CSV et version imprimable/PDF.
9. Paramètres: nom/description, montant/fréquence (quotidienne, hebdomadaire, mensuelle ou personnalisée), échéances/règles, administrateurs et droits.

## Structure prévue (starter réel: React / Express / tRPC / Drizzle)
- `client/src/pages/`: connexion, dashboard et vues des neuf modules métier.
- `client/src/components/`: navigation bureau/mobile, cartes de synthèse, tableaux/formulaires, confirmations, états vide/chargement/erreur.
- `client/src/lib/`: client tRPC, formatage XAF/dates, helpers de rapports.
- `client/public/`: manifeste/routes et marque/icône si nécessaire.
- `server/_core/`: démarrage Express, parsing du cookie de session et garde-fous globaux.
- `server/auth.ts` ou `server/_core/localAuth.ts`: dérivation scrypt, création/connexion/révocation de sessions et premier administrateur.
- `server/db.ts`: requêtes et transactions pour les entités métier.
- `server/routers.ts` et `server/routers/`: routes tRPC validées et protégées, services de calcul des statistiques, retards, règles et journal.
- `drizzle/schema.ts`, `drizzle/*.sql`: schéma MySQL et migrations déterministes.
- `shared/`: contrats partagés et validation des entrées.
- `public/manus-routes.json`: manifeste complet des routes de page.

## Direction de conception
- **Mouvement**: dashboard financier éditorial africain contemporain, inspiré par la sobriété des interfaces bancaires premium, avec un accent graphique original plutôt qu’un folklore décoratif.
- **Principes**: clarté financière immédiate; confiance par la traçabilité; densité maîtrisée; actions tactiles et accessibles.
- **Couleurs**: encre noire profonde pour le cadre et l’autorité; or chaud propre à la marque pour les actions prioritaires et repères de circulation; fond ivoire/blanc et gris doux pour le confort de lecture; vert/rouge réservés aux états sémantiques et jamais comme unique signal.
- **Parcours/layout**: panneau latéral compact sur bureau, barre basse de navigation sur téléphone, contenus à largeur confortable avec une colonne de synthèse et un fil chronologique des opérations; filtres adaptables et tableaux qui deviennent des cartes lisibles au mobile.
- **Signatures visuelles**: monogramme « D » construit en anneau de tontine; marqueurs dorés de progression du tour; lignes de flux distinctes pour entrées et sorties.
- **Interactions/animation**: formulaires courts avec validation locale et serveur; confirmation pour toute action financière sensible; retours toast et états explicites; transitions discrètes de 150–220 ms, pas d’animation décorative ni de chiffre fictif animé.
- **Typographie**: « Manrope » ou système sans-serif géométrique pour l’interface; chiffres tabulaires pour FCFA, tailles adaptées à la lecture mobile; titres sobres et contrastes accessibles.
- **Essence**: « La tontine de votre communauté, tenue avec une clarté financière digne d’un outil professionnel. » Personnalité: fiable, chaleureuse, rigoureuse.
- **Voix**: français direct, précis et respectueux; exemple de titre: « La confiance se suit, tour après tour. » Exemple d’action: « Enregistrer une cotisation ».
- **Logotype**: anneau doré segmenté entourant une lettre D noire, à côté du nom DANNE; ne pas employer un mot-symbole générique.
- **Couleur signature**: or DANNE `#D7A72E`, complété par charbon `#121212`.

## Déploiement et limites
Prévisualisation via le serveur Cloud sur le port déjà configuré. Base de développement et publication partagée: éviter tests de mutation destructifs et ne jamais se connecter à des données réelles pour une recette automatique. Déploiement/publication distincts de la prévisualisation; aucune publication publique n’est implicite. Utilisation Android via navigateur Chrome; documenter l’ajout à l’écran d’accueil si le manifeste PWA est ajouté. Avant mise en production financière: créer l’administrateur initial, vérifier les droits, définir les règles et tester en données de démonstration; activer séparément tout fournisseur de notification ou Mobile Money nécessaire.

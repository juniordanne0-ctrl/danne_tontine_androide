import { execFileSync } from "node:child_process";

const raw = process.env.DANNE_APP_URL?.trim();
if (!raw) {
  console.error("DANNE_APP_URL manque. Publiez d'abord DANNE TONTINE et indiquez son URL HTTPS stable.");
  process.exit(1);
}

let url;
try {
  url = new URL(raw);
} catch {
  console.error("DANNE_APP_URL n'est pas une URL valide.");
  process.exit(1);
}
if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash) {
  console.error("DANNE_APP_URL doit être une URL HTTPS publique, sans identifiants, paramètres ou fragment.");
  process.exit(1);
}

console.log(`Préparation des ressources Android pour ${url.origin}…`);
execFileSync("pnpm", ["build"], { stdio: "inherit", env: process.env });
execFileSync("pnpm", ["exec", "cap", "sync", "android"], { stdio: "inherit", env: process.env });

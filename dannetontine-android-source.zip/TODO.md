# DANNE TONTINE — critères de réalisation

Toutes les cases restent ouvertes jusqu’à ce que le comportement correspondant soit implémenté et vérifié.

## 1. Identité visuelle et format
- [ ] Nom : DANNE TONTINE; style africain moderne, élégant, professionnel, premium et simple à utiliser; noir profond principal, jaune d’or pour boutons importants/icônes/mises en valeur, blanc et gris clair pour la lisibilité; typographie moderne, cartes élégantes, icônes cohérentes, tableaux lisibles.
- [ ] Interface entièrement en français; toutes les sommes affichées en FCFA (XAF).

## 2. Connexion, rôles et confidentialité
- [ ] Écran de connexion et authentification sécurisée par téléphone ou courriel + mot de passe (choix confirmé par l’utilisateur); ne jamais stocker les mots de passe en clair.
- [ ] Rôles : Administrateur gère la tontine et ses paramètres; Trésorier enregistre cotisations et paiements selon ses autorisations; Membre consulte uniquement les informations autorisées.
- [ ] Protéger les données de chaque tontine pour qu’un utilisateur ne puisse pas consulter celles d’une autre tontine sans autorisation; vérifier les permissions côté serveur.

## 3. Tableau de bord et agrégats réels
- [ ] Afficher total des cotisations encaissées; total des paiements effectués aux bénéficiaires; solde calculé à partir des opérations; nombre total de membres actifs, en retard et bloqués; montant des cotisations attendues; prochain bénéficiaire et date prévue; dernières opérations enregistrées.
- [ ] Ajouter des graphiques simples pour visualiser cotisations et paiements.
- [ ] Toutes les statistiques proviennent des données réellement enregistrées dans la base, sans chiffres inventés.

## 4. Membres
- [ ] Ajouter un membre, modifier ses informations, consulter sa fiche, rechercher par nom ou téléphone, filtrer par statut, activer/suspendre/bloquer/réactiver selon les autorisations.
- [ ] Formulaire : nom complet; numéro de téléphone; adresse facultative; date d’inscription; montant de cotisation prévu; fréquence; statut; notes facultatives.
- [ ] Chaque membre possède un identifiant unique.
- [ ] Ne pas supprimer définitivement un membre ayant des opérations financières; désactivation ou archivage avec historique conservé.

## 5. Cotisations
- [ ] Enregistrer une cotisation en choisissant le membre, montant en FCFA, date, mode de paiement, référence de transaction et commentaire facultatif.
- [ ] Consulter les cotisations d’un membre; filtrer par période, membre et statut.
- [ ] Corriger une opération avec autorisation et conserver une trace de la modification.
- [ ] Modes disponibles : espèces, MTN Mobile Money, Orange Money, virement bancaire et autre.
- [ ] Ne pas prétendre confirmer automatiquement un paiement Mobile Money; sans intégration officielle, identifier les opérations comme saisies manuellement.
- [ ] Empêcher les doubles enregistrements involontaires.

## 6. Paiements aux bénéficiaires
- [ ] Sélectionner le bénéficiaire; afficher le montant prévu; saisir montant réellement versé, date, mode de paiement, référence et commentaire; marquer en attente/payé/annulé; consulter les paiements précédents.
- [ ] Un paiement annulé n’est pas comptabilisé comme paiement effectué.
- [ ] Demander une confirmation avant l’enregistrement d’un paiement important ou l’annulation d’une opération.

## 7. Retards et blocages
- [ ] Calculer automatiquement les retards à partir des échéances et cotisations réellement enregistrées.
- [ ] Afficher nom du membre, montant attendu, montant déjà payé, montant restant, jours de retard et prochaine échéance.
- [ ] L’administrateur peut bloquer ou réactiver un membre avec motif obligatoire et date.
- [ ] Un blocage n’efface jamais l’historique financier.
- [ ] Alertes visuelles et rappels; aucun SMS ou notification externe sans intégration et autorisation appropriées.

## 8. Ordre des bénéficiaires
- [ ] Ajouter des membres à la liste; définir/modifier l’ordre; afficher bénéficiaire actuel et suivants; définir une date prévue par tour; enregistrer montant prévu; marquer un tour payé uniquement après confirmation; consulter l’historique des tours.
- [ ] Empêcher le paiement en double du même tour.
- [ ] Ne pas modifier silencieusement l’ordre après un paiement : demander confirmation et conserver l’historique des changements.

## 9. Historique centralisé et rapports
- [ ] Historique centralisé de cotisations, paiements aux bénéficiaires, annulations, corrections, blocages/réactivations et modifications importantes.
- [ ] Chaque opération possède une date, un identifiant, un montant si nécessaire, l’utilisateur responsable et son statut.
- [ ] Filtres par membre, date, type d’opération et statut.
- [ ] Exportation CSV et, si possible, PDF.

## 10. Paramètres de la tontine
- [ ] Configurer nom, description, montant de cotisation, fréquence quotidienne/hebdomadaire/mensuelle/personnalisée, dates des échéances, règles de retard, règles de blocage et administrateurs autorisés.
- [ ] Les changements de paramètres ne modifient pas rétroactivement les opérations déjà enregistrées sans procédure contrôlée de correction.

## 11. Navigation et usage Android
- [ ] Menu avec : Tableau de bord, Membres, Cotisations, Paiements, Retards et blocages, Bénéficiaires, Historique, Rapports, Paramètres.
- [ ] Sur téléphone : navigation pratique, boutons suffisamment grands et formulaires simples.
- [ ] États de chargement, messages de succès/erreur, confirmations et pages vides explicites.
- [ ] Aucun bouton décoratif dépourvu de fonctionnalité.

## 12. Schéma, intégrité et persistance
- [ ] Base de données sécurisée et persistante compatible avec la plateforme.
- [ ] Relations cohérentes entre utilisateurs, tontines, membres, cotisations, paiements, tours bénéficiaires et historique.
- [ ] Données disponibles après actualisation, fermeture du navigateur et reconnexion; ne pas utiliser uniquement données fictives, variables temporaires ou stockage local du navigateur comme solution finale.
- [ ] Si une configuration externe, clé API ou connexion manuelle est nécessaire, documenter précisément les étapes; ne déclarer une intégration active qu’après test.

## 13. Vérification avant livraison
- [ ] Tester ajout et modification d’un membre; enregistrement d’une cotisation; calcul du solde; paiements et annulations; calcul des retards; blocage et réactivation; modification de l’ordre des bénéficiaires; autorisations entre utilisateurs; persistance après actualisation; petit écran Android; corriger les erreurs détectées.
- [ ] Tests sans suppression ni mutations d’essai dans les données réelles, la base de développement étant partagée avec la publication.
- [ ] Créer des données de démonstration explicitement identifiées, séparées des données réelles, et fournir une méthode sûre pour les retirer.

## 14. Livraison et mise en route
- [ ] Fournir l’adresse de prévisualisation de l’application.
- [ ] Fournir les étapes pour tester toutes les fonctionnalités.
- [ ] Indiquer les éventuelles configurations restantes.
- [ ] Fournir les étapes pour publier l’application et l’utiliser sur Android.
- [ ] Ne pas déclarer une fonctionnalité terminée si elle n’a pas été implémentée et vérifiée.

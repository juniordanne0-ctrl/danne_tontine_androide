package com.dannetontine.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tontineId` int NOT NULL,
	`actorId` int NOT NULL,
	`entityType` varchar(48) NOT NULL,
	`entityId` varchar(64),
	`action` varchar(48) NOT NULL,
	`amount` bigint,
	`details` text,
	`status` varchar(32) NOT NULL,
	`isDemo` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `auth_attempts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`keyHash` varchar(64) NOT NULL,
	`attempts` int NOT NULL DEFAULT 0,
	`windowStartedAt` timestamp NOT NULL DEFAULT (now()),
	`lockedUntil` timestamp,
	CONSTRAINT `auth_attempts_id` PRIMARY KEY(`id`),
	CONSTRAINT `auth_attempts_keyHash_unique` UNIQUE(`keyHash`)
);
--> statement-breakpoint
CREATE TABLE `auth_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`tokenHash` varchar(64) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`revokedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `auth_sessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `auth_sessions_tokenHash_unique` UNIQUE(`tokenHash`)
);
--> statement-breakpoint
CREATE TABLE `beneficiary_turns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tontineId` int NOT NULL,
	`memberId` int NOT NULL,
	`position` int NOT NULL,
	`plannedDate` date NOT NULL,
	`plannedAmount` bigint NOT NULL,
	`status` enum('planned','paid') NOT NULL DEFAULT 'planned',
	`paidAt` timestamp,
	`isDemo` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `beneficiary_turns_id` PRIMARY KEY(`id`),
	CONSTRAINT `turn_group_position_uq` UNIQUE(`tontineId`,`position`)
);
--> statement-breakpoint
CREATE TABLE `contributions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tontineId` int NOT NULL,
	`memberId` int NOT NULL,
	`amount` bigint NOT NULL,
	`paidAt` timestamp NOT NULL,
	`paymentMethod` enum('cash','mtn_momo','orange_money','bank_transfer','other') NOT NULL,
	`reference` varchar(120),
	`comment` text,
	`status` enum('confirmed','reversed') NOT NULL DEFAULT 'confirmed',
	`isManual` boolean NOT NULL DEFAULT true,
	`isDemo` boolean NOT NULL DEFAULT false,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contributions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `members` (
	`id` int AUTO_INCREMENT NOT NULL,
	`publicId` varchar(32) NOT NULL,
	`tontineId` int NOT NULL,
	`linkedUserId` int,
	`fullName` varchar(160) NOT NULL,
	`phone` varchar(40) NOT NULL,
	`email` varchar(320),
	`address` text,
	`joinedAt` date NOT NULL,
	`expectedAmount` bigint NOT NULL,
	`frequency` enum('daily','weekly','monthly','custom') NOT NULL,
	`status` enum('active','suspended','blocked','archived') NOT NULL DEFAULT 'active',
	`notes` text,
	`isDemo` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `members_id` PRIMARY KEY(`id`),
	CONSTRAINT `members_publicId_unique` UNIQUE(`publicId`)
);
--> statement-breakpoint
CREATE TABLE `tontine_memberships` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tontineId` int NOT NULL,
	`userId` int NOT NULL,
	`role` enum('admin','treasurer','member') NOT NULL DEFAULT 'member',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tontine_memberships_id` PRIMARY KEY(`id`),
	CONSTRAINT `membership_group_user_uq` UNIQUE(`tontineId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `payouts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tontineId` int NOT NULL,
	`turnId` int NOT NULL,
	`memberId` int NOT NULL,
	`amount` bigint NOT NULL,
	`paidAt` timestamp,
	`paymentMethod` enum('cash','mtn_momo','orange_money','bank_transfer','other') NOT NULL,
	`reference` varchar(120),
	`comment` text,
	`status` enum('pending','paid','cancelled') NOT NULL DEFAULT 'pending',
	`isDemo` boolean NOT NULL DEFAULT false,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payouts_id` PRIMARY KEY(`id`),
	CONSTRAINT `payouts_turnId_unique` UNIQUE(`turnId`)
);
--> statement-breakpoint
CREATE TABLE `tontines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`description` text,
	`contributionAmount` bigint NOT NULL DEFAULT 0,
	`frequency` enum('daily','weekly','monthly','custom') NOT NULL DEFAULT 'monthly',
	`customDueDates` text,
	`lateDays` int NOT NULL DEFAULT 0,
	`blockDays` int NOT NULL DEFAULT 30,
	`threshold` bigint NOT NULL DEFAULT 100000,
	`isDemo` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tontines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(40);--> statement-breakpoint
ALTER TABLE `users` ADD `loginIdentifier` varchar(320);--> statement-breakpoint
ALTER TABLE `users` ADD `passwordHash` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `initialAdmin` varchar(1);--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_phone_unique` UNIQUE(`phone`);--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_loginIdentifier_unique` UNIQUE(`loginIdentifier`);--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_initialAdmin_unique` UNIQUE(`initialAdmin`);--> statement-breakpoint
ALTER TABLE `audit_logs` ADD CONSTRAINT `audit_logs_tontineId_tontines_id_fk` FOREIGN KEY (`tontineId`) REFERENCES `tontines`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `audit_logs` ADD CONSTRAINT `audit_logs_actorId_users_id_fk` FOREIGN KEY (`actorId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `auth_sessions` ADD CONSTRAINT `auth_sessions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `beneficiary_turns` ADD CONSTRAINT `beneficiary_turns_tontineId_tontines_id_fk` FOREIGN KEY (`tontineId`) REFERENCES `tontines`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `beneficiary_turns` ADD CONSTRAINT `beneficiary_turns_memberId_members_id_fk` FOREIGN KEY (`memberId`) REFERENCES `members`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `contributions` ADD CONSTRAINT `contributions_tontineId_tontines_id_fk` FOREIGN KEY (`tontineId`) REFERENCES `tontines`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `contributions` ADD CONSTRAINT `contributions_memberId_members_id_fk` FOREIGN KEY (`memberId`) REFERENCES `members`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `contributions` ADD CONSTRAINT `contributions_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `members` ADD CONSTRAINT `members_tontineId_tontines_id_fk` FOREIGN KEY (`tontineId`) REFERENCES `tontines`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `members` ADD CONSTRAINT `members_linkedUserId_users_id_fk` FOREIGN KEY (`linkedUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `tontine_memberships` ADD CONSTRAINT `tontine_memberships_tontineId_tontines_id_fk` FOREIGN KEY (`tontineId`) REFERENCES `tontines`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `tontine_memberships` ADD CONSTRAINT `tontine_memberships_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `payouts` ADD CONSTRAINT `payouts_tontineId_tontines_id_fk` FOREIGN KEY (`tontineId`) REFERENCES `tontines`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `payouts` ADD CONSTRAINT `payouts_turnId_beneficiary_turns_id_fk` FOREIGN KEY (`turnId`) REFERENCES `beneficiary_turns`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `payouts` ADD CONSTRAINT `payouts_memberId_members_id_fk` FOREIGN KEY (`memberId`) REFERENCES `members`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `payouts` ADD CONSTRAINT `payouts_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `audit_group_date_idx` ON `audit_logs` (`tontineId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `auth_sessions_user_idx` ON `auth_sessions` (`userId`);--> statement-breakpoint
CREATE INDEX `turn_group_date_idx` ON `beneficiary_turns` (`tontineId`,`plannedDate`);--> statement-breakpoint
CREATE INDEX `contributions_group_date_idx` ON `contributions` (`tontineId`,`paidAt`);--> statement-breakpoint
CREATE INDEX `contributions_group_member_idx` ON `contributions` (`tontineId`,`memberId`);--> statement-breakpoint
CREATE INDEX `members_group_name_idx` ON `members` (`tontineId`,`fullName`);--> statement-breakpoint
CREATE INDEX `members_group_phone_idx` ON `members` (`tontineId`,`phone`);--> statement-breakpoint
CREATE INDEX `payouts_group_date_idx` ON `payouts` (`tontineId`,`paidAt`);
import {
  bigint,
  boolean,
  date,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 40 }).unique(),
  loginIdentifier: varchar("loginIdentifier", { length: 320 }).unique(),
  loginMethod: varchar("loginMethod", { length: 64 }),
  passwordHash: varchar("passwordHash", { length: 255 }),
  initialAdmin: varchar("initialAdmin", { length: 1 }).unique(),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const authSessions = mysqlTable("auth_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  tokenHash: varchar("tokenHash", { length: 64 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  revokedAt: timestamp("revokedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [index("auth_sessions_user_idx").on(table.userId)]);

export const authAttempts = mysqlTable("auth_attempts", {
  id: int("id").autoincrement().primaryKey(),
  keyHash: varchar("keyHash", { length: 64 }).notNull().unique(),
  attempts: int("attempts").notNull().default(0),
  windowStartedAt: timestamp("windowStartedAt").defaultNow().notNull(),
  lockedUntil: timestamp("lockedUntil"),
});

export const tontines = mysqlTable("tontines", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  description: text("description"),
  contributionAmount: bigint("contributionAmount", { mode: "number" }).notNull().default(0),
  frequency: mysqlEnum("frequency", ["daily", "weekly", "monthly", "custom"]).notNull().default("monthly"),
  customDueDates: text("customDueDates"),
  lateDays: int("lateDays").notNull().default(0),
  blockDays: int("blockDays").notNull().default(30),
  threshold: bigint("threshold", { mode: "number" }).notNull().default(100000),
  isDemo: boolean("isDemo").notNull().default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const memberships = mysqlTable("tontine_memberships", {
  id: int("id").autoincrement().primaryKey(),
  tontineId: int("tontineId").notNull().references(() => tontines.id),
  userId: int("userId").notNull().references(() => users.id),
  role: mysqlEnum("role", ["admin", "treasurer", "member"]).notNull().default("member"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [uniqueIndex("membership_group_user_uq").on(table.tontineId, table.userId)]);

export const members = mysqlTable("members", {
  id: int("id").autoincrement().primaryKey(),
  publicId: varchar("publicId", { length: 32 }).notNull().unique(),
  tontineId: int("tontineId").notNull().references(() => tontines.id),
  linkedUserId: int("linkedUserId").references(() => users.id),
  fullName: varchar("fullName", { length: 160 }).notNull(),
  phone: varchar("phone", { length: 40 }).notNull(),
  email: varchar("email", { length: 320 }),
  address: text("address"),
  joinedAt: date("joinedAt", { mode: "string" }).notNull(),
  expectedAmount: bigint("expectedAmount", { mode: "number" }).notNull(),
  frequency: mysqlEnum("frequency", ["daily", "weekly", "monthly", "custom"]).notNull(),
  status: mysqlEnum("status", ["active", "suspended", "blocked", "archived"]).notNull().default("active"),
  notes: text("notes"),
  isDemo: boolean("isDemo").notNull().default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [index("members_group_name_idx").on(table.tontineId, table.fullName), index("members_group_phone_idx").on(table.tontineId, table.phone)]);

export const beneficiaryTurns = mysqlTable("beneficiary_turns", {
  id: int("id").autoincrement().primaryKey(),
  tontineId: int("tontineId").notNull().references(() => tontines.id),
  memberId: int("memberId").notNull().references(() => members.id),
  position: int("position").notNull(),
  plannedDate: date("plannedDate", { mode: "string" }).notNull(),
  plannedAmount: bigint("plannedAmount", { mode: "number" }).notNull(),
  status: mysqlEnum("status", ["planned", "paid"]).notNull().default("planned"),
  paidAt: timestamp("paidAt"),
  isDemo: boolean("isDemo").notNull().default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [uniqueIndex("turn_group_position_uq").on(table.tontineId, table.position), index("turn_group_date_idx").on(table.tontineId, table.plannedDate)]);

export const contributions = mysqlTable("contributions", {
  id: int("id").autoincrement().primaryKey(),
  tontineId: int("tontineId").notNull().references(() => tontines.id),
  memberId: int("memberId").notNull().references(() => members.id),
  amount: bigint("amount", { mode: "number" }).notNull(),
  paidAt: timestamp("paidAt").notNull(),
  paymentMethod: mysqlEnum("paymentMethod", ["cash", "mtn_momo", "orange_money", "bank_transfer", "other"]).notNull(),
  reference: varchar("reference", { length: 120 }),
  comment: text("comment"),
  status: mysqlEnum("status", ["confirmed", "reversed"]).notNull().default("confirmed"),
  isManual: boolean("isManual").notNull().default(true),
  isDemo: boolean("isDemo").notNull().default(false),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [index("contributions_group_date_idx").on(table.tontineId, table.paidAt), index("contributions_group_member_idx").on(table.tontineId, table.memberId)]);

export const payouts = mysqlTable("payouts", {
  id: int("id").autoincrement().primaryKey(),
  tontineId: int("tontineId").notNull().references(() => tontines.id),
  turnId: int("turnId").notNull().unique().references(() => beneficiaryTurns.id),
  memberId: int("memberId").notNull().references(() => members.id),
  amount: bigint("amount", { mode: "number" }).notNull(),
  paidAt: timestamp("paidAt"),
  paymentMethod: mysqlEnum("paymentMethod", ["cash", "mtn_momo", "orange_money", "bank_transfer", "other"]).notNull(),
  reference: varchar("reference", { length: 120 }),
  comment: text("comment"),
  status: mysqlEnum("status", ["pending", "paid", "cancelled"]).notNull().default("pending"),
  isDemo: boolean("isDemo").notNull().default(false),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [index("payouts_group_date_idx").on(table.tontineId, table.paidAt)]);

export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  tontineId: int("tontineId").notNull().references(() => tontines.id),
  actorId: int("actorId").notNull().references(() => users.id),
  entityType: varchar("entityType", { length: 48 }).notNull(),
  entityId: varchar("entityId", { length: 64 }),
  action: varchar("action", { length: 48 }).notNull(),
  amount: bigint("amount", { mode: "number" }),
  details: text("details"),
  status: varchar("status", { length: 32 }).notNull(),
  isDemo: boolean("isDemo").notNull().default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [index("audit_group_date_idx").on(table.tontineId, table.createdAt)]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

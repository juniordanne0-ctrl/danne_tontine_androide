import { trpc } from "@/lib/trpc";
import { useCallback, useEffect } from "react";

type UseAuthOptions = { redirectOnUnauthenticated?: boolean; redirectPath?: string };

export function useAuth(options?: UseAuthOptions) {
  const { redirectOnUnauthenticated = false, redirectPath = "/" } = options ?? {};
  const utils = trpc.useUtils();
  const meQuery = trpc.auth.me.useQuery(undefined, { retry: false, refetchOnWindowFocus: false });
  const logoutMutation = trpc.auth.logout.useMutation({ onSuccess: () => { void utils.auth.me.invalidate(); } });
  const logout = useCallback(async () => {
    try { await logoutMutation.mutateAsync(); } finally { await utils.auth.me.invalidate(); }
  }, [logoutMutation, utils]);
  useEffect(() => {
    if (!redirectOnUnauthenticated || meQuery.isLoading || meQuery.data) return;
    if (typeof window !== "undefined" && window.location.pathname !== redirectPath) window.location.assign(redirectPath);
  }, [redirectOnUnauthenticated, redirectPath, meQuery.isLoading, meQuery.data]);
  return {
    user: meQuery.data ?? null,
    loading: meQuery.isLoading || logoutMutation.isPending,
    error: meQuery.error ?? logoutMutation.error ?? null,
    isAuthenticated: Boolean(meQuery.data),
    refresh: () => meQuery.refetch(),
    logout,
  };
}

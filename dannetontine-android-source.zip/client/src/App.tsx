import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";

function Router() {
  return <Switch>
    <Route path="/" component={Home}/>
    <Route path="/members" component={Home}/>
    <Route path="/contributions" component={Home}/>
    <Route path="/payouts" component={Home}/>
    <Route path="/delays" component={Home}/>
    <Route path="/beneficiaries" component={Home}/>
    <Route path="/history" component={Home}/>
    <Route path="/reports" component={Home}/>
    <Route path="/settings" component={Home}/>
    <Route component={Home}/>
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster/><Router/></TooltipProvider></ThemeProvider></ErrorBoundary>;
}

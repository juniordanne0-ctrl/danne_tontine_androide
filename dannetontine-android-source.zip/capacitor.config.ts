import type { CapacitorConfig } from "@capacitor/cli";

const appUrl = process.env.DANNE_APP_URL?.trim();
if (appUrl) {
  const parsed = new URL(appUrl);
  if (parsed.protocol !== "https:") {
    throw new Error("DANNE_APP_URL doit être une adresse HTTPS de production.");
  }
}

const config: CapacitorConfig = {
  appId: "com.dannetontine.app",
  appName: "DANNE TONTINE",
  webDir: "dist/public",
  ...(appUrl ? { server: { url: appUrl, cleartext: false } } : {}),
};

export default config;
